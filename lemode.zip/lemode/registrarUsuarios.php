<?php
    include("BaseDatos.php");
    if (isset($_POST["botonEnvio"])){
        
        $nombre = $_POST["nombre"];
        $apellido=$_POST["precio"];
        $descripcion=$_POST["descripcion"];
        $foto=$_POST["foto"];
        
        $transaccion=new BaseDatos();
         
        $consultaSQL="INSERT INTO usuarios(nombre,precio,descripcion,foto) VALUES ('$nombre','$apellido','$descripcion','$foto')";
       
        $transaccion->agregarDatos($consultaSQL);
        header("location:listaUsuarios.php");
        
    }
?>